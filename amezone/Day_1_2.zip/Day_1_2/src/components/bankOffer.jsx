import React from 'react';

const BankOffer = ()=>{
 return (<>
     <div className="bank-wraperr mt-[15px]">
         <div className="container mx-auto bg-white">
             <div className="row flex justify-center">
                 <img src="https://rukminim1.flixcart.com/fk-p-flap/1600/140/image/cecebca2292c7948.jpg?q=20" alt="" />
             </div>
         </div>
     </div>
 </>)
}

export default BankOffer;