import React from "react";
import Header from "./components/header";
import TopSale from "./components/topSale";
import Carosule from "./components/carosule";
import BankOffer from "./components/bankOffer";
import BestMobile from "./components/BestMobile";
import DaySale from "./components/DaySale"

function App() {
    
    let imgArr = ["https://rukminim2.flixcart.com/fk-p-flap/520/280/image/8bc07230b5ef20f4.jpg?q=20",
    "https://rukminim2.flixcart.com/fk-p-flap/520/280/image/93c68a7eadd552e6.png?q=20",
    "https://rukminim2.flixcart.com/fk-p-flap/520/280/image/3a0f369e4b2ef15a.jpg?q=20"]

    let arr = [
        {
            src:"https://rukminim2.flixcart.com/image/312/312/xif0q/mobile/n/i/d/-original-imagpgx4erjqnpzx.jpeg?q=70",
            title:"Google Pixel 7a"
        }, {
            src: "https://rukminim2.flixcart.com/image/312/312/xif0q/mobile/u/m/b/-original-imagrdefbw6bhbjr.jpeg?q=70",
            title: "Nothing Phone (2)"
        }, {
            src: "https://rukminim2.flixcart.com/image/312/312/xif0q/mobile/5/e/3/g84-5g-paym0018in-motorola-original-imagsy5zmhvkcfsx.jpeg?q=70 ",
            title: "MOTOROLA g84 5G"
        }, {
            src: "https://rukminim2.flixcart.com/image/312/312/xif0q/mobile/t/k/m/11-pro-5g-rmx3741-realme-original-imagq6asfa6hg5eu.jpeg?q=70",
            title: "realme 11 Pro+ 5G "
        }, {
            src: "https://rukminim2.flixcart.com/image/200/200/xif0q/mobile/m/j/o/-original-imaghkvue4yjecju.jpeg?q=70",
            title: "Redmi Note 12 Pro 5G"
        },
        {
            src: "https://rukminim2.flixcart.com/image/312/312/xif0q/mobile/u/m/b/-original-imagrdefbw6bhbjr.jpeg?q=70",
            title: "Nothing Phone (2)"
        }, {
            src: "https://rukminim2.flixcart.com/image/312/312/xif0q/mobile/5/e/3/g84-5g-paym0018in-motorola-original-imagsy5zmhvkcfsx.jpeg?q=70 ",
            title: "MOTOROLA g84 5G"
        }]

    return (
    <>
        <Header></Header>
        <TopSale></TopSale>
        <Carosule></Carosule>
        <BankOffer></BankOffer>
        <BestMobile MobileData={arr} title="Best Mobile"></BestMobile>
        <DaySale imgArr={imgArr}/>
    </>
    )
}
export default App;